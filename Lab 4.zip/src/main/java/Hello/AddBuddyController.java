package Hello;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AddBuddyController {
    @Autowired
    private AddressBookRepository aRepo;

    @Autowired
    private BuddyInfoRepository bRepo;

    @RequestMapping("/CreateAddressBook")
    public void CreateAddressBook() {
        AddressBook book = new AddressBook();
        aRepo.save(book);
    }

    @RequestMapping("/AddBuddy")
    public void AddBuddy(@RequestParam(value = "name",required = true) String name, @RequestParam(value = "phoneNumber",required = true) String phoneNumber) {
        long one = 1;
        AddressBook book = aRepo.findOne(one);
        BuddyInfo b = new BuddyInfo(name,phoneNumber);
        book.addBuddy(b);
        bRepo.save(b);
        aRepo.save(book);
    }
}
